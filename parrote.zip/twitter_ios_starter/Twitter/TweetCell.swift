//
//  TweetCell.swift
//  Twitter
//
//  Created by Patrick Brothers on 3/11/22.
//  Copyright © 2022 Dan. All rights reserved.
//

import UIKit

class TweetCell: UITableViewCell {
    var favorited: Bool = false
    var retweeted: Bool = false
    var tweetId: Int = -1
    
    @IBOutlet weak var profilePictureView: UIImageView!
    
    @IBOutlet weak var authorLabel: UILabel!
    
    @IBOutlet weak var contentLabel: UILabel!
    
    @IBOutlet weak var favButton: UIButton!
    
    @IBOutlet weak var retweetButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setTweetId(_ id: Int){
        self.tweetId = id
    }
    
    func setRetweeted(_ retweet_status: Bool){
        self.retweeted = retweet_status
        
        if (retweet_status) {
            retweetButton.setImage(UIImage(named: "retweet-icon-green"), for: UIControl.State.normal)
            retweetButton.isEnabled = false
        } else {
            retweetButton.setImage(UIImage(named: "retweet-icon"), for: UIControl.State.normal)
            retweetButton.isEnabled = true
        }
    }
    
    func setFavorite(_ isFavorited: Bool){
        favorited=isFavorited
        
        if (isFavorited) {
            favButton.setImage(UIImage(named: "favor-icon-red"), for: UIControl.State.normal)
        } else {
            favButton.setImage(UIImage(named: "favor-icon"), for: UIControl.State.normal)
        }
    }
    
    @IBAction func favoriteTweet(_ sender: Any) {
        
        // if pressed while favorited, we unfavorite
        if(favorited){
            TwitterAPICaller.client?.unFavoriteTweet(tweetId: tweetId, success: {
                self.setFavorite(false)
            }, failure: { Error in
                print("could not unfavorite tweet")
            })
        } else {
            TwitterAPICaller.client?.favoriteTweet(tweetId: tweetId, success: {
                self.setFavorite(true)
                self.favButton.setTitle(String(Int(self.favButton.currentTitle!)!+1), for: UIControl.State.normal)
            }, failure: { Error in
                print("could not favorite tweet")
            })
        }
    }
    
    @IBAction func retweet(_ sender: Any) {
        TwitterAPICaller.client?.retweet(tweetId: self.tweetId, success: {
            self.setRetweeted(true)
        }, failure: { Error in
            print("could not retweet")
        })
    }
}
